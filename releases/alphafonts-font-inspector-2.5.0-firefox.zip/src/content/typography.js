/*
 * Typography helpers for the content script:
 *  - reading computed styles
 *  - guessing the rendered font
 *  - building the "Copy CSS" and "Copy Info" text
 *  - describing an element and generating a short CSS selector
 *
 * Nothing here touches the page: it only reads.
 */
(function () {
  const AF = (globalThis.AlphaFonts = globalThis.AlphaFonts || {});
  const { UNAVAILABLE } = AF.constants;
  const utils = AF.utils;

  // ---------------------------------------------------------------------
  // Reading computed styles
  // ---------------------------------------------------------------------

  /** Reads one computed property. Returns null when it is missing or unsupported. */
  function readProperty(style, name) {
    try {
      const value = style.getPropertyValue(name);
      return value && value.trim() ? value.trim() : null;
    } catch (e) {
      return null;
    }
  }

  const PROPERTIES = {
    fontFamily: 'font-family',
    fontSize: 'font-size',
    fontWeight: 'font-weight',
    fontStyle: 'font-style',
    fontVariant: 'font-variant',
    fontStretch: 'font-stretch',
    lineHeight: 'line-height',
    letterSpacing: 'letter-spacing',
    wordSpacing: 'word-spacing',
    textAlign: 'text-align',
    textTransform: 'text-transform',
    textDecorationLine: 'text-decoration-line',
    textDecorationStyle: 'text-decoration-style',
    textDecorationThickness: 'text-decoration-thickness',
    color: 'color',
    opacity: 'opacity',
    textRendering: 'text-rendering',
    whiteSpace: 'white-space'
  };

  /**
   * Collects typography data for an element.
   * Missing values are null, so the UI can show "Unavailable" or hide them.
   */
  function getTypographyData(element) {
    const data = {};
    let style = null;
    try {
      style = window.getComputedStyle(element);
    } catch (e) {
      style = null;
    }
    for (const key of Object.keys(PROPERTIES)) {
      data[key] = style ? readProperty(style, PROPERTIES[key]) : null;
    }
    data.renderedFont = detectRenderedFont(data.fontFamily);
    data.previewText = getPreviewText(element);
    return data;
  }

  const PREVIEW_MAX_LENGTH = 60;

  /**
   * A short sample of the element's own text for the panel preview.
   * Only the element's direct text is used (not its children), it is cut short,
   * and password fields are never read.
   */
  function getPreviewText(element) {
    try {
      let raw = '';
      if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
        if (element.type === 'password') return '';
        raw = element.value || element.placeholder || '';
      } else {
        for (const node of element.childNodes) {
          if (node.nodeType === Node.TEXT_NODE) raw += node.nodeValue + ' ';
        }
      }
      const text = raw.replace(/\s+/g, ' ').trim();
      return text.length > PREVIEW_MAX_LENGTH ? text.slice(0, PREVIEW_MAX_LENGTH - 1).trimEnd() + '\u2026' : text;
    } catch (e) {
      return '';
    }
  }

  const SKIPPED_TAGS = ['SCRIPT', 'STYLE', 'NOSCRIPT', 'TEMPLATE'];

  /** True if the element directly contains text worth inspecting (not just child elements). */
  function hasOwnText(element) {
    if (SKIPPED_TAGS.includes(element.tagName)) return false;
    if (element.tagName === 'INPUT' || element.tagName === 'TEXTAREA') {
      return !!(element.value || element.placeholder);
    }
    if (element.tagName === 'SELECT') return true;
    for (const node of element.childNodes) {
      if (node.nodeType === Node.TEXT_NODE && /\S/.test(node.nodeValue)) return true;
    }
    return false;
  }

  /**
   * A cheap version of getTypographyData for the page-wide labels: computed styles only,
   * no font detection, because it runs for hundreds of elements at once.
   */
  function getLabelData(element) {
    const data = {};
    try {
      const style = window.getComputedStyle(element);
      for (const key of Object.keys(PROPERTIES)) data[key] = readProperty(style, PROPERTIES[key]);
    } catch (e) {
      // Leave the values empty: the label simply shows less.
    }
    return data;
  }

  /**
   * The color behind an element's text: its own background mixed with its parents' until
   * something opaque is found (white if nothing is). `uncertain` is true when an image or
   * gradient is involved, because then no single color describes the background.
   */
  function getBackground(element) {
    const layers = [];
    let uncertain = false;
    for (let node = element; node && node.nodeType === 1; node = node.parentElement) {
      let style;
      try {
        style = window.getComputedStyle(node);
      } catch (e) {
        break;
      }
      if (style.backgroundImage && style.backgroundImage !== 'none') uncertain = true;
      const color = utils.parseColor(style.backgroundColor);
      if (color && color.a > 0) {
        layers.push(color);
        if (color.a >= 1) break;
      }
    }
    let base = { r: 255, g: 255, b: 255, a: 1 };
    if (layers.length && layers[layers.length - 1].a >= 1) base = layers.pop();
    for (let i = layers.length - 1; i >= 0; i--) base = utils.blend(layers[i], base);
    return { color: base, uncertain };
  }

  /** Contrast of the element's text against its background, or null if it cannot be worked out. */
  function getContrast(element, data) {
    try {
      const text = utils.parseColor(data.color);
      if (!text) return null;
      const background = getBackground(element);
      const info = utils.contrastInfo(text, background.color, parseFloat(data.fontSize) || 16, data.fontWeight);
      info.uncertain = background.uncertain;
      return info;
    } catch (e) {
      return null;
    }
  }

  // ---------------------------------------------------------------------
  // "Likely rendered font"
  // ---------------------------------------------------------------------
  // Browsers do not tell pages which font file was really used. As a hint we
  // walk the font stack and pick the first family that the browser can
  // actually load (installed or a loaded web font), by comparing text widths
  // against generic fallbacks. It is a good guess, not a guarantee, so the UI
  // always calls it "likely".

  let measureContext = null;
  const SAMPLE_TEXT = 'mmmmmmmmmmlliWWiiAaQq@#0123456789';
  const BASELINES = ['monospace', 'serif', 'sans-serif'];

  function getMeasureContext() {
    if (!measureContext) {
      measureContext = document.createElement('canvas').getContext('2d');
    }
    return measureContext;
  }

  function isFamilyAvailable(name) {
    const ctx = getMeasureContext();
    if (!ctx) return false;
    const quoted = '"' + name.replace(/["\\]/g, '\\$&') + '"';
    for (const baseline of BASELINES) {
      ctx.font = '72px ' + baseline;
      const baseWidth = ctx.measureText(SAMPLE_TEXT).width;
      ctx.font = '72px ' + quoted + ', ' + baseline;
      if (ctx.measureText(SAMPLE_TEXT).width !== baseWidth) return true;
    }
    return false;
  }

  /** Returns the first available named family in the stack, or null if we cannot tell. */
  function detectRenderedFont(fontFamilyValue) {
    try {
      for (const name of utils.parseFontStack(fontFamilyValue)) {
        // Reaching a generic/system family means the OS picks the font: stop guessing.
        if (utils.isGenericFamily(name) || utils.isSystemFamily(name)) return null;
        if (isFamilyAvailable(name)) return name;
      }
    } catch (e) {
      // Fall through: "unknown" is always a safe answer.
    }
    return null;
  }

  // ---------------------------------------------------------------------
  // Text output
  // ---------------------------------------------------------------------

  function hasValue(value) {
    return !!value && value !== UNAVAILABLE;
  }

  function isDefaultStretch(value) {
    return value === 'normal' || value === '100%';
  }

  function isDefaultSpacing(value) {
    return value === 'normal' || value === '0px';
  }

  /** `enabled` is the settings.properties map. Without it, everything is included. */
  function isEnabled(enabled, key) {
    return !enabled || enabled[key] !== false;
  }

  /** Builds the CSS block for "Copy CSS". Only enabled properties with real values are included. */
  function buildCSS(data, enabled) {
    const lines = [];
    const add = (property, value) => {
      if (hasValue(value)) lines.push(property + ': ' + value + ';');
    };
    const on = (key) => isEnabled(enabled, key);

    if (on('fontFamily')) add('font-family', data.fontFamily);
    if (on('fontSize')) add('font-size', data.fontSize);
    if (on('fontWeight')) add('font-weight', data.fontWeight);
    if (on('fontStyle')) {
      add('font-style', data.fontStyle);
      if (hasValue(data.fontVariant) && data.fontVariant !== 'normal') add('font-variant', data.fontVariant);
      if (hasValue(data.fontStretch) && !isDefaultStretch(data.fontStretch)) add('font-stretch', data.fontStretch);
    }
    if (on('lineHeight')) add('line-height', data.lineHeight);
    if (on('letterSpacing')) add('letter-spacing', data.letterSpacing);
    if (on('wordSpacing') && hasValue(data.wordSpacing) && !isDefaultSpacing(data.wordSpacing)) {
      add('word-spacing', data.wordSpacing);
    }
    if (on('fontColor')) add('color', data.color);
    if (on('textAlign')) add('text-align', data.textAlign);
    if (on('textTransform')) add('text-transform', data.textTransform);
    if (on('textDecoration') && hasValue(data.textDecorationLine) && data.textDecorationLine !== 'none') {
      add('text-decoration-line', data.textDecorationLine);
      add('text-decoration-style', data.textDecorationStyle);
      if (data.textDecorationThickness !== 'auto') add('text-decoration-thickness', data.textDecorationThickness);
    }
    return lines.join('\n');
  }

  /** Wraps declarations in a rule: ".hero-title {\n  font-size: 18px;\n}" */
  function wrapRule(css, selector) {
    if (!css || !selector) return css;
    return selector + ' {\n' + css.split('\n').map((line) => '  ' + line).join('\n') + '\n}';
  }

  function colorForInfo(raw) {
    const parsed = utils.parseColor(raw);
    if (parsed && utils.isOpaque(parsed)) return raw + ' (' + utils.toHex(parsed) + ')';
    return raw;
  }

  /** Builds the readable summary for "Copy Info". */
  function buildInfo(data, elementInfo, enabled) {
    const lines = ['AlphaFonts Font Inspector', ''];
    const add = (label, value) => {
      if (hasValue(value)) lines.push(label + ': ' + value);
    };
    const on = (key) => isEnabled(enabled, key);

    if (on('fontFamily')) {
      add('Font Family', data.fontFamily);
      add('Likely Rendered Font', data.renderedFont);
    }
    if (on('fontSize')) add('Font Size', data.fontSize);
    if (on('fontWeight')) add('Font Weight', data.fontWeight);
    if (on('fontStyle')) {
      add('Font Style', data.fontStyle);
      if (hasValue(data.fontVariant) && data.fontVariant !== 'normal') add('Font Variant', data.fontVariant);
      if (hasValue(data.fontStretch) && !isDefaultStretch(data.fontStretch)) add('Font Stretch', data.fontStretch);
    }
    if (on('lineHeight')) add('Line Height', data.lineHeight);
    if (on('letterSpacing')) add('Letter Spacing', data.letterSpacing);
    if (on('wordSpacing') && hasValue(data.wordSpacing) && !isDefaultSpacing(data.wordSpacing)) {
      add('Word Spacing', data.wordSpacing);
    }
    if (on('fontColor') && hasValue(data.color)) add('Color', colorForInfo(data.color));
    if (on('textAlign')) add('Text Align', data.textAlign);
    if (on('textTransform')) add('Text Transform', data.textTransform);
    if (on('textDecoration') && hasValue(data.textDecorationLine) && data.textDecorationLine !== 'none') {
      add('Text Decoration', [data.textDecorationLine, data.textDecorationStyle].filter(hasValue).join(' '));
    }
    if (hasValue(data.opacity) && data.opacity !== '1') add('Opacity', data.opacity);
    if (elementInfo) {
      add('Element', elementInfo.tag.toLowerCase());
      add('Selector', elementInfo.selector);
    }
    return lines.join('\n');
  }

  // ---------------------------------------------------------------------
  // Element description and selector
  // ---------------------------------------------------------------------

  const UNSTABLE_CLASS_PREFIXES = ['css-', 'sc-', 'jsx-', 'emotion-', 'styled-', 'svelte-', 'ng-'];

  /** Classes/ids that look hand-written, not generated (hashes, utility classes with symbols). */
  function isStableToken(token) {
    if (!token || token.length > 40) return false;
    if (/\d{4,}/.test(token)) return false;
    if (/[:\[\]/%#!@]/.test(token)) return false;
    const lower = token.toLowerCase();
    return !UNSTABLE_CLASS_PREFIXES.some((prefix) => lower.startsWith(prefix));
  }

  function getClassList(element) {
    const raw = element.getAttribute && element.getAttribute('class');
    return raw ? raw.split(/\s+/).filter(Boolean) : [];
  }

  /** Plain facts about the element for the "Element" section. */
  function describeElement(element) {
    const classes = getClassList(element);
    return {
      tag: element.tagName || 'UNKNOWN',
      id: element.id || '',
      classes: classes.join(' ')
    };
  }

  function escapeIdent(value) {
    return typeof CSS !== 'undefined' && CSS.escape ? CSS.escape(value) : value.replace(/[^\w-]/g, '\\$&');
  }

  function tagOf(element) {
    return element.tagName.toLowerCase();
  }

  function nthOfType(element) {
    let index = 1;
    for (let sib = element.previousElementSibling; sib; sib = sib.previousElementSibling) {
      if (sib.tagName === element.tagName) index++;
    }
    return index;
  }

  function hasSameTagSibling(element) {
    const parent = element.parentElement;
    if (!parent) return false;
    for (const sib of parent.children) {
      if (sib !== element && sib.tagName === element.tagName) return true;
    }
    return false;
  }

  /** One step of a selector: #id, or tag.class.class, or tag:nth-of-type(n). */
  function selectorSegment(element) {
    if (element.id && isStableToken(element.id)) return '#' + escapeIdent(element.id);
    const classes = getClassList(element).filter(isStableToken).slice(0, 2);
    if (classes.length) return tagOf(element) + classes.map((c) => '.' + escapeIdent(c)).join('');
    const tag = tagOf(element);
    return hasSameTagSibling(element) ? tag + ':nth-of-type(' + nthOfType(element) + ')' : tag;
  }

  /** Guaranteed-unique fallback: tag:nth-of-type steps up to an id or <body>. */
  function pathSelector(element) {
    const parts = [];
    let node = element;
    while (node && node.nodeType === 1 && node !== document.body && node !== document.documentElement) {
      if (node.id && isStableToken(node.id)) {
        parts.unshift('#' + escapeIdent(node.id));
        return parts.join(' > ');
      }
      parts.unshift(tagOf(node) + ':nth-of-type(' + nthOfType(node) + ')');
      node = node.parentElement;
    }
    if (document.body && node === document.body) parts.unshift('body');
    return parts.join(' > ');
  }

  /**
   * Builds a short, reasonably stable selector such as ".hero-title" or "#main-heading".
   * Tries the shortest options first and only grows when needed.
   */
  function generateSelector(element) {
    try {
      const scope = element.getRootNode();
      const isUnique = (selector) => {
        try {
          const matches = scope.querySelectorAll(selector);
          return matches.length === 1 && matches[0] === element;
        } catch (e) {
          return false;
        }
      };

      // 1. #id or a single class on its own.
      if (element.id && isStableToken(element.id) && isUnique('#' + escapeIdent(element.id))) {
        return '#' + escapeIdent(element.id);
      }
      const classes = getClassList(element).filter(isStableToken).slice(0, 3);
      for (const name of classes) {
        const selector = '.' + escapeIdent(name);
        if (isUnique(selector)) return selector;
      }

      // 2. Add the tag and parents until the selector is unique (at most 3 parents).
      const parts = [selectorSegment(element)];
      if (isUnique(parts[0])) return parts[0];
      let parent = element.parentElement;
      for (let depth = 0; depth < 3 && parent && parent !== document.documentElement; depth++) {
        parts.unshift(selectorSegment(parent));
        const selector = parts.join(' > ');
        if (isUnique(selector)) return selector;
        parent = parent.parentElement;
      }

      // 3. Last resort: a full path, always unique.
      return pathSelector(element);
    } catch (e) {
      return tagOf(element);
    }
  }

  AF.typography = {
    getTypographyData,
    getLabelData,
    getContrast,
    hasOwnText,
    detectRenderedFont,
    buildCSS,
    wrapRule,
    buildInfo,
    describeElement,
    generateSelector
  };
})();
